#### Düzenlenen yeni Etiket Tagger Botudur. 
#### Start mesajı içerisinde log id yazmayı unutmayın. 
